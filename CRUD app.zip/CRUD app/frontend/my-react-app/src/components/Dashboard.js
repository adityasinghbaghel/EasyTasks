import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Dashboard.css';
import { logout, fetchTodos, createTodo, updateTodo, deleteTodo } from '../services/api';
import TodoForm from './TodoForm';
import Modal from './Modal';

const Dashboard = () => {
    const [todos, setTodos] = useState([]);
    const [editingTodo, setEditingTodo] = useState(null);
    const [modalOpen, setModalOpen] = useState(false); // Modal control
    const navigate = useNavigate();

    useEffect(() => {
        fetchAllTodos();
    }, []);

    const fetchAllTodos = async () => {
        try {
            const todos = await fetchTodos();
            setTodos(todos);
        } catch (error) {
            console.error('Error fetching todos:', error);
        }
    };

    const handleLogout = async () => {
        try {
            await logout();
            navigate('/login'); // Redirect to login page
        } catch (error) {
            console.error('Logout error', error);
        }
    };

    const handleAddTodo = () => {
        setEditingTodo(null);
        setModalOpen(true); // Open modal
    };

    const handleSaveTodo = async (todo) => {
        try {
            if (editingTodo) {
                await updateTodo(editingTodo.id, todo);
            } else {
                await createTodo(todo);
            }
            fetchAllTodos();
            setModalOpen(false); // Close modal
        } catch (error) {
            console.error('Error saving todo:', error);
        }
    };

    const handleEditTodo = (todo) => {
        setEditingTodo(todo);
        setModalOpen(true); // Open modal
    };

    const handleDeleteTodo = async (id) => {
        try {
            await deleteTodo(id);
            fetchAllTodos();
        } catch (error) {
            console.error('Error deleting todo:', error);
        }
    };

    return (
        <div className="dashboard-container">
            <div className="sidebar">
                <h2>Dashboard</h2>
                <ul>
                    <li><a href="/dashboard">Home</a></li>

                    <li><button onClick={handleLogout} className="logout-button">Logout</button></li>
                </ul>
            </div>
            <div className="content">
                <div className="header">
                    <h1>Welcome to the Dashboard</h1>
                    <button className="new-todo-button" onClick={handleAddTodo}> <b>New Todo</b></button>
                </div>
                <div className="todos">
                    {todos.length ? (
                        todos.map(todo => (
                            <div className="todo-item" key={todo.id}>
                                <h3>{todo.title}</h3>
                                <p>{todo.description}</p>
                                <p><b>Status: </b>{todo.completed ? 'Completed' : 'Not Completed'}</p>
                                <button onClick={() => handleEditTodo(todo)}>Edit</button>
                                <button onClick={() => handleDeleteTodo(todo.id)}>Delete</button>
                            </div>
                        ))
                    ) : (
                        <p>No todos found 😕</p>
                    )}
                </div>
            </div>

            <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)}>
                <TodoForm onSave={handleSaveTodo} todo={editingTodo} />
            </Modal>
        </div>
    );
};

export default Dashboard;
