import React, { useState, useEffect } from 'react';

const TodoForm = ({ onSave, todo }) => {
  const [title, setTitle] = useState(todo ? todo.title : '');
  const [description, setDescription] = useState(todo ? todo.description : '');
  const [completed, setCompleted] = useState(todo ? todo.completed : false);

  useEffect(() => {
    if (todo) {
      setTitle(todo.title);
      setDescription(todo.description);
      setCompleted(todo.completed);
    }
  }, [todo]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({ title, description, completed });
  };

  return (
    <form 
      onSubmit={handleSubmit}
      style={{
        backgroundColor: '#fff',
        padding: '1rem',
        margin: '0 auto',
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem'
      }}>
        
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <label style={{ color: '#00796b', fontWeight: 'bold', marginBottom: '0.5rem' }}>Title</label>
        <input 
          value={title} 
          onChange={(e) => setTitle(e.target.value)} 
          required 
          style={{
            padding: '0.5rem',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '1rem',
            color: '#333'
          }}
        />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <label style={{ color: '#00796b', fontWeight: 'bold', marginBottom: '0.5rem' }}>Description</label>
        <textarea 
          value={description} 
          onChange={(e) => setDescription(e.target.value)} 
          style={{
            padding: '0.5rem',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '1rem',
            color: '#333',
            resize: 'vertical',
            minHeight: '100px'
          }}
        />
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <label style={{ color: '#00796b', fontWeight: 'bold' }}>Completed</label>
        <input 
          type="checkbox" 
          checked={completed} 
          onChange={(e) => setCompleted(e.target.checked)}
          style={{ marginRight: '0.5rem' }}
        />
      </div>
      <button 
        type="submit"
        style={{
          backgroundColor: '#00796b',
          color: 'white',
          border: 'none',
          padding: '0.5rem 1rem',
          borderRadius: '4px',
          cursor: 'pointer',
          fontSize: '1rem',
          transition: 'background-color 0.3s'
        }}
        onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#004d40'}
        onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#00796b'}
      >
        {todo ? 'Update' : 'Add'} Todo
      </button>
    </form>
  );
};

export default TodoForm;
