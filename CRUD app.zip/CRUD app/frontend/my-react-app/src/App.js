// frontend/src/App.js
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Signup from './components/Signup';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import { register, login, logout } from './services/api'; // Import the functions from api.js
import axios from 'axios';

const PrivateRoute = ({ children }) => {
  const token = localStorage.getItem('token');
  return token ? children : <Navigate to="/login" />;
};


const App = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      setUser({ token });
    }
  }, []);

  const handleSignup = async (credentials) => {
    try {
      const data = await register(credentials);
      setUser({ token: data.token });
      localStorage.setItem('token', data.token);
      axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
    } catch (error) {
      console.error('Signup error', error);
    }
  };

  const handleLogin = async (credentials) => {
    try {
      const data = await login(credentials);
      console.log("data:", data);
      console.log("set user:", setUser({ token: data.token }));
      setUser({ token: data.token });
      localStorage.setItem('token', data.token);
      axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
    } catch (error) {
      console.error('Login error', error);
    }
  };

  return (
    <Router>
      <Routes>
        <Route path="/signup" element={<Signup handleSignup={handleSignup} />} />
        <Route path="/login" element={<Login handleLogin={handleLogin} />} />
        {/* <Route path="/logout" element={<Logout handleLogout={handleLogout} />} /> */}
        <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>}/>
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
};

export default App;
