class User < ApplicationRecord
    has_secure_password
    validates :email, presence: true, uniqueness: true
    validates :password, presence: true, length: { minimum: 6 }
    validates :password_confirmation, presence: true, if: :password_present?

    def generate_token
        JWT.encode({ user_id: self.id }, Rails.application.secrets.secret_key_base, 'HS256')
    end

    def self.decode_token(token)
        decoded_token = JWT.decode(token, Rails.application.secrets.secret_key_base, true, { algorithm: 'HS256' })
        User.find(decoded_token[0]["user_id"])
      rescue
        nil
    end

    private

    def password_present?
        password.present?
    end
end


