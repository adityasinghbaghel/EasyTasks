class Api::V1::AuthController < ApplicationController
  skip_before_action :verify_authenticity_token
  
    def signup
        user = User.new(user_params)
        if user.save
          render json: { token: user.generate_token }, status: :created
        else
          render json: { errors: user.errors.full_messages }, status: :unprocessable_entity
        end
    end


    def login
      user = User.find_by(email: params[:auth][:user][:email])
      if user&.authenticate(params[:auth][:user][:password])
        render json: { token: user.generate_token }, status: :ok
      else
        render json: { errors: ["Invalid email or password"] }, status: :unauthorized
      end
    end

    private

    def user_params
      params.require(:user).permit(:email, :password, :password_confirmation)
    end
end
