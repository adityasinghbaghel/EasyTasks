class ApplicationController < ActionController::Base
    def authorize_request
        header = request.headers['Authorization']
        header = header.split(' ').last if header
        @decoded = User.decode_token(header)
        @current_user = User.find(@decoded[:user_id]) if @decoded
    rescue ActiveRecord::RecordNotFound, JWT::DecodeError
        render json: { errors: ['Not Authorized'] }, status: :unauthorized
    end
end